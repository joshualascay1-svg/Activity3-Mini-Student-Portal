# Activity 3 – Mini Student Portal

A React single-page application demonstrating routing, controlled forms, validation, lifted state, and list/detail views.

## Requirements

- React + Vite
- React Router
- Controlled registration form
- Validation for all required fields
- Student ID format: `####-####`
- Email format validation
- Lifted student state in `App.jsx`
- Student list and detail routes
- 404 route

## Run the project

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Routes

- `/` – Home
- `/register` – Register a student
- `/students` – Student list
- `/students/:id` – Student details
- `*` – Page not found

## Test flow

1. Open Home.
2. Open Register.
3. Submit the empty form and verify the five validation messages.
4. Enter `2024123` as the Student ID and verify the format error.
5. Enter valid student information and register.
6. Verify the new student appears in `/students`.
7. Click the student's name to open the details.
8. Visit `/students/9999-9999` and verify `Student not found`.
9. Visit `/hello` and verify `Page not found`.
