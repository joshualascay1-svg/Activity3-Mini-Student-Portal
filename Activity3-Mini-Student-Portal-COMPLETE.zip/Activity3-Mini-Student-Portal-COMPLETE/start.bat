@echo off
echo Starting Mini Student Portal...
npm install
npm run dev
pause
