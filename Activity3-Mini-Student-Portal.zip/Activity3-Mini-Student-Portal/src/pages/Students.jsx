// TODO 6: import { Link } from "react-router-dom";
import { yearLabel } from "../data/students.js";

// TODO 6: Render one table row per student with map().
//   - Use key={s.id}
//   - The name should be a link: <Link to={`/students/${s.id}`}>{s.fullName}</Link>
//   - Show the course and yearLabel(s.yearLevel)
export default function Students({ students }) {
  return (
    <section>
      <h1>Students</h1>
      <p className="lead">{students.length} registered. Select a name to see the details.</p>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th scope="col">Student ID</th>
              <th scope="col">Name</th>
              <th scope="col">Course</th>
              <th scope="col">Year</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colSpan={4}><span className="todo">TODO 6: students.map(...)</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  );
}
