// TODO 6: import { useParams, useNavigate, Link } from "react-router-dom";
import { yearLabel } from "../data/students.js";

// TODO 6: Show ONE student using the id in the URL (/students/:id).
//   1. const { id } = useParams();
//   2. const student = students.find((s) => s.id === id);
//   3. If no student is found, show "Student not found" and a link back to /students.
//   4. Otherwise show the ID, email, course, and year level.
//   5. Add a "Back to students" button that calls navigate("/students").
export default function StudentDetail({ students }) {
  return (
    <section>
      <h1>Student details</h1>
      <p className="todo">TODO 6: read the id with useParams() and display the student.</p>
    </section>
  );
}
