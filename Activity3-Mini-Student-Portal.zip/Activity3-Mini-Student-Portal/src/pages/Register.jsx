// TODO 3: import useState from "react"
// TODO 5: import { useNavigate } from "react-router-dom"
import { COURSES, YEAR_LEVELS, yearLabel } from "../data/students.js";
import { validate } from "../utils/validate.js";

// TODO 3: Make every field CONTROLLED.
//   1. const [form, setForm] = useState({ fullName: "", studentId: "", email: "", course: "", yearLevel: "" });
//   2. Write ONE handleChange:
//        const { name, value } = e.target;
//        setForm((prev) => ({ ...prev, [name]: value }));
//   3. Add value={form.xxx} and onChange={handleChange} to each input and the select.
//      For radio buttons use checked={form.yearLevel === y}.
//
// TODO 4: const [errors, setErrors] = useState({});
//   In handleSubmit, call validate(form), save the result with setErrors, and stop if there are errors.
//   Show each message under its field:  {errors.email && <small className="error">{errors.email}</small>}
//
// TODO 5: If the form is valid, call onAdd({ id: form.studentId, fullName, email, course, yearLevel })
//   and then navigate("/students").
export default function Register({ students, onAdd }) {
  function handleSubmit(e) {
    e.preventDefault();
    // TODO 4 and 5
  }

  return (
    <section>
      <h1>Register a student</h1>
      <p className="lead">All fields are required.</p>

      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="field">
          <label htmlFor="fullName">Full name</label>
          <input id="fullName" name="fullName" type="text" />
        </div>

        <div className="field">
          <label htmlFor="studentId">Student ID</label>
          <input id="studentId" name="studentId" type="text" placeholder="2024-0123" />
          <p className="hint">Format: four digits, a dash, four digits.</p>
        </div>

        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" name="email" type="email" />
        </div>

        <div className="field">
          <label htmlFor="course">Course</label>
          <select id="course" name="course">
            <option value="">Choose a course</option>
            {COURSES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <div className="field">
          <fieldset>
            <legend>Year level</legend>
            <div className="radio-group">
              {YEAR_LEVELS.map((y) => (
                <label key={y}>
                  <input type="radio" name="yearLevel" value={y} />
                  {yearLabel(y)}
                </label>
              ))}
            </div>
          </fieldset>
        </div>

        <button type="submit" className="btn btn-primary">Register student</button>
      </form>
    </section>
  );
}
