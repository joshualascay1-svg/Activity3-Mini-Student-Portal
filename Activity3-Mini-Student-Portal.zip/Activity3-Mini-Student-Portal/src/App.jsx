// TODO 5: import useState from "react"
// TODO 1-2: import { Routes, Route, NavLink, Link } from "react-router-dom";
import { INITIAL_STUDENTS } from "./data/students.js";
import Home from "./pages/Home.jsx";
import Register from "./pages/Register.jsx";
import Students from "./pages/Students.jsx";
import StudentDetail from "./pages/StudentDetail.jsx";
import NotFound from "./pages/NotFound.jsx";

export default function App() {
  // TODO 5: Lift the student list here, because Register AND Students both need it.
  //   const [students, setStudents] = useState(INITIAL_STUDENTS);
  //   function addStudent(student) { setStudents((prev) => [...prev, student]); }
  const students = INITIAL_STUDENTS;

  return (
    <>
      <header className="topbar">
        <span className="brand">Mini Student Portal</span>
        {/* TODO 2: Build the navigation with NavLink:
              <NavLink to="/" end>Home</NavLink>
              <NavLink to="/register">Register</NavLink>
              <NavLink to="/students">Students</NavLink>
            The CSS already styles the "active" class that NavLink adds. */}
        <nav aria-label="Main">
          <span className="todo">TODO 2: navigation links</span>
        </nav>
      </header>

      <main className="page">
        {/* TODO 1: Replace <Home ... /> with <Routes> containing these routes:
              /              -> <Home count={students.length} />
              /register      -> <Register students={students} onAdd={addStudent} />
              /students      -> <Students students={students} />
              /students/:id  -> <StudentDetail students={students} />
              *              -> <NotFound />
            Home.jsx uses <Link>, which only works after TODO 1 (BrowserRouter + Routes). */}
        <h1>Mini Student Portal</h1>
        <p className="todo">
          TODO 1: Wrap the app in BrowserRouter (main.jsx) and add the Routes here.
          When you finish, the Home page will appear in place of this box.
        </p>
      </main>
    </>
  );
}
